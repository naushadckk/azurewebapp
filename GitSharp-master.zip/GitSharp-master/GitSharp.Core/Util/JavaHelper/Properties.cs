using System;

namespace GitSharp.Core.Util.JavaHelper
{
    public class Properties
    {
        public string getProperty(string key)
        {
            throw new NotImplementedException();
        }

        public string getProperty(string key, string defaultValue)
        {
            throw new NotImplementedException();
        }
    }
}