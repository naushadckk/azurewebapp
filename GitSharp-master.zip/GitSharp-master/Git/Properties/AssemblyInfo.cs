﻿using System.Reflection;

[assembly: AssemblyTitle("git")]
[assembly: AssemblyDescription("Command line interface for GitSharp")]
