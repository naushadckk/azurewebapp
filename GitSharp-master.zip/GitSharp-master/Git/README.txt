CLI (Command Line Interface) is a not so close port of jgit's pgm-package and 
shall be equivalent to the original git command line.

The implemented git commands are located in Commands
The auto-generated command stubs are located in Stubs. They will be moved to Commands once implemented.

The CLI commands rely on the command API in GitSharp.Commands